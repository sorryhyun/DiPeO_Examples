// src/main.tsx
/* src/main.tsx
   Application bootstrap. Mounts React tree into DOM, wraps App with providers (React Query Provider) and imports global styles.
   - Creates React Query client using core/queryClient factory
   - Wraps App with QueryClientProvider
   - Handles StrictMode in development
   - Imports global styles
*/

import React from 'react';
import { createRoot } from 'react-dom/client';
import { QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';

import App from '@/app/App';
import { createQueryClient } from '@/core/queryClient';
import { isDevelopment } from '@/app/config';
import '@/styles/global.css';

// Create the React Query client instance
const queryClient = createQueryClient();

// Bootstrap the application
function mountApp() {
  const container = document.getElementById('root');
  if (!container) {
    throw new Error('Root element not found. Make sure your HTML includes <div id="root"></div>');
  }

  const root = createRoot(container);

  const AppWithProviders = (
    <QueryClientProvider client={queryClient}>
      <App />
      {isDevelopment && <ReactQueryDevtools initialIsOpen={false} />}
    </QueryClientProvider>
  );

  // Wrap in StrictMode for development to catch potential issues
  if (isDevelopment) {
    root.render(
      <React.StrictMode>
        {AppWithProviders}
      </React.StrictMode>
    );
  } else {
    root.render(AppWithProviders);
  }
}

// Mount the app immediately
mountApp();

// Export for testing purposes
export default mountApp;

/*
- [x] Uses `@/` imports only
- [x] Uses providers/hooks (no direct DOM/localStorage side effects) - uses React Query Provider
- [x] Reads config from `@/app/config` - imports isDevelopment
- [x] Exports default named component - exports mountApp function
- [x] Adds basic ARIA and keyboard handlers (not relevant for bootstrap file)
*/
```

```typescript
// src/core/queryClient.ts
/* src/core/queryClient.ts
   React Query client factory and configuration.
   - Creates QueryClient with sensible defaults
   - Configures retry logic, stale times, and error handling
   - Provides global query/mutation defaults
*/

import { QueryClient, QueryClientConfig } from '@tanstack/react-query';
import { isDevelopment } from '@/app/config';

// Default configuration for React Query
const queryClientConfig: QueryClientConfig = {
  defaultOptions: {
    queries: {
      // How long before data is considered stale
      staleTime: 5 * 60 * 1000, // 5 minutes
      // How long to keep unused data in cache
      gcTime: 10 * 60 * 1000, // 10 minutes (previously cacheTime)
      // Retry failed requests
      retry: (failureCount, error) => {
        // Don't retry on 4xx errors (client errors)
        if (error && typeof error === 'object' && 'status' in error) {
          const status = (error as any).status;
          if (status >= 400 && status < 500) {
            return false;
          }
        }
        // Retry up to 3 times for other errors
        return failureCount < 3;
      },
      // Retry delay with exponential backoff
      retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
      // Don't refetch on window focus in development
      refetchOnWindowFocus: !isDevelopment,
      // Refetch on network reconnect
      refetchOnReconnect: true,
    },
    mutations: {
      // Retry mutations once on network error
      retry: (failureCount, error) => {
        if (failureCount < 1) {
          // Only retry on network errors, not client/server errors
          if (error && typeof error === 'object' && 'message' in error) {
            const message = (error as any).message?.toLowerCase() || '';
            return message.includes('network') || message.includes('fetch');
          }
        }
        return false;
      },
    },
  },
};

// Factory function to create a new QueryClient instance
export function createQueryClient(): QueryClient {
  return new QueryClient(queryClientConfig);
}

// Create default instance for use throughout the app
export const queryClient = createQueryClient();

/*
- [x] Uses `@/` imports only
- [x] Uses providers/hooks (no direct DOM/localStorage side effects)
- [x] Reads config from `@/app/config` - imports isDevelopment
- [x] Exports default named component - exports factory function and default instance
- [x] Adds basic ARIA and keyboard handlers (not relevant for query client)
*/
```

```css
/* src/styles/global.css
   Global application styles including CSS reset, typography, and utility classes.
   - Modern CSS reset
   - Root CSS variables for consistent theming
   - Typography scale
   - Utility classes for common patterns
*/

/* CSS Reset and base styles */
*, *::before, *::after {
  box-sizing: border-box;
}

* {
  margin: 0;
}

html, body {
  height: 100%;
}

body {
  line-height: 1.5;
  -webkit-font-smoothing: antialiased;
}

img, picture, video, canvas, svg {
  display: block;
  max-width: 100%;
}

input, button, textarea, select {
  font: inherit;
}

p, h1, h2, h3, h4, h5, h6 {
  overflow-wrap: break-word;
}

#root {
  height: 100%;
  isolation: isolate;
}

/* CSS Custom Properties for theming */
:root {
  /* Colors */
  --color-primary: #3b82f6;
  --color-primary-hover: #2563eb;
  --color-primary-light: #dbeafe;
  
  --color-secondary: #64748b;
  --color-secondary-hover: #475569;
  
  --color-success: #22c55e;
  --color-warning: #f59e0b;
  --color-error: #ef4444;
  --color-info: #06b6d4;
  
  --color-gray-50: #f8fafc;
  --color-gray-100: #f1f5f9;
  --color-gray-200: #e2e8f0;
  --color-gray-300: #cbd5e1;
  --color-gray-400: #94a3b8;
  --color-gray-500: #64748b;
  --color-gray-600: #475569;
  --color-gray-700: #334155;
  --color-gray-800: #1e293b;
  --color-gray-900: #0f172a;
  
  --color-white: #ffffff;
  --color-black: #000000;
  
  /* Background and text */
  --bg-primary: var(--color-white);
  --bg-secondary: var(--color-gray-50);
  --bg-accent: var(--color-gray-100);
  
  --text-primary: var(--color-gray-900);
  --text-secondary: var(--color-gray-600);
  --text-muted: var(--color-gray-500);
  
  /* Borders */
  --border-color: var(--color-gray-200);
  --border-radius: 0.375rem;
  --border-radius-sm: 0.25rem;
  --border-radius-lg: 0.5rem;
  
  /* Shadows */
  --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
  --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  
  /* Spacing scale */
  --space-xs: 0.25rem;
  --space-sm: 0.5rem;
  --space-md: 1rem;
  --space-lg: 1.5rem;
  --space-xl: 2rem;
  --space-2xl: 3rem;
  
  /* Typography */
  --font-family-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  --font-family-mono: 'Fira Code', 'Monaco', 'Cascadia Code', 'Roboto Mono', Consolas, 'Courier New', monospace;
  
  --font-size-xs: 0.75rem;
  --font-size-sm: 0.875rem;
  --font-size-base: 1rem;
  --font-size-lg: 1.125rem;
  --font-size-xl: 1.25rem;
  --font-size-2xl: 1.5rem;
  --font-size-3xl: 1.875rem;
  --font-size-4xl: 2.25rem;
  
  --font-weight-normal: 400;
  --font-weight-medium: 500;
  --font-weight-semibold: 600;
  --font-weight-bold: 700;
  
  --line-height-tight: 1.25;
  --line-height-normal: 1.5;
  --line-height-relaxed: 1.75;
}

/* Base typography */
body {
  font-family: var(--font-family-sans);
  font-size: var(--font-size-base);
  line-height: var(--line-height-normal);
  color: var(--text-primary);
  background-color: var(--bg-primary);
}

h1, h2, h3, h4, h5, h6 {
  font-weight: var(--font-weight-semibold);
  line-height: var(--line-height-tight);
  color: var(--text-primary);
}

h1 { font-size: var(--font-size-4xl); }
h2 { font-size: var(--font-size-3xl); }
h3 { font-size: var(--font-size-2xl); }
h4 { font-size: var(--font-size-xl); }
h5 { font-size: var(--font-size-lg); }
h6 { font-size: var(--font-size-base); }

p {
  color: var(--text-secondary);
}

a {
  color: var(--color-primary);
  text-decoration: none;
}

a:hover {
  color: var(--color-primary-hover);
  text-decoration: underline;
}

/* Utility classes */
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0;
}

.container {
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 var(--space-md);
}

.flex {
  display: flex;
}

.flex-col {
  flex-direction: column;
}

.items-center {
  align-items: center;
}

.justify-center {
  justify-content: center;
}

.justify-between {
  justify-content: space-between;
}

.gap-sm {
  gap: var(--space-sm);
}

.gap-md {
  gap: var(--space-md);
}

.gap-lg {
  gap: var(--space-lg);
}

.text-center {
  text-align: center;
}

.text-sm {
  font-size: var(--font-size-sm);
}

.text-lg {
  font-size: var(--font-size-lg);
}

.font-medium {
  font-weight: var(--font-weight-medium);
}

.font-semibold {
  font-weight: var(--font-weight-semibold);
}

.text-muted {
  color: var(--text-muted);
}

.text-secondary {
  color: var(--text-secondary);
}

.bg-secondary {
  background-color: var(--bg-secondary);
}

.border {
  border: 1px solid var(--border-color);
}

.rounded {
  border-radius: var(--border-radius);
}

.shadow {
  box-shadow: var(--shadow);
}

.p-sm {
  padding: var(--space-sm);
}

.p-md {
  padding: var(--space-md);
}

.p-lg {
  padding: var(--space-lg);
}

.m-auto {
  margin: auto;
}

.mb-sm {
  margin-bottom: var(--space-sm);
}

.mb-md {
  margin-bottom: var(--space-md);
}

.mb-lg {
  margin-bottom: var(--space-lg);
}

.w-full {
  width: 100%;
}

.h-full {
  height: 100%;
}

.min-h-screen {
  min-height: 100vh;
}

/* Focus styles for accessibility */
:focus-visible {
  outline: 2px solid var(--color-primary);
  outline-offset: 2px;
}

/* Dark mode support (optional - can be extended later) */
@media (prefers-color-scheme: dark) {
  :root {
    --bg-primary: var(--color-gray-900);
    --bg-secondary: var(--color-gray-800);
    --bg-accent: var(--color-gray-700);
    
    --text-primary: var(--color-gray-100);
    --text-secondary: var(--color-gray-300);
    --text-muted: var(--color-gray-400);
    
    --border-color: var(--color-gray-700);
  }
}

/* Loading and transition utilities */
.loading {
  opacity: 0.7;
  pointer-events: none;
}

.fade-in {
  animation: fadeIn 0.2s ease-in-out;
}

@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

/* Print styles */
@media print {
  * {
    background: transparent !important;
    color: black !important;
    box-shadow: none !important;
    text-shadow: none !important;
  }
  
  a, a:visited {
    text-decoration: underline;
  }
  
  .no-print {
    display: none !important;
  }
}

/*
- [x] Uses `@/` imports only (not applicable to CSS)
- [x] Uses providers/hooks (no direct DOM/localStorage side effects) (not applicable to CSS)
- [x] Reads config from `@/app/config` (not applicable to CSS)
- [x] Exports default named component (not applicable to CSS)
- [x] Adds basic ARIA and keyboard handlers (focus-visible styles included)
*/
