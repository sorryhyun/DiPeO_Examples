import React from 'react';

export interface ButtonProps {
  children: React.ReactNode;
  onClick?: (event: React.MouseEvent<HTMLButtonElement>) => void;
  type?: 'button' | 'submit' | 'reset';
  className?: string;
  disabled?: boolean;
  'aria-label'?: string;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  onClick,
  type = 'button',
  className = '',
  disabled = false,
  'aria-label': ariaLabel,
}) => {
  const baseClasses = `
    px-4 py-2 font-medium rounded-md transition-colors duration-200
    focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500
    dark:focus:ring-offset-gray-800
  `;

  const enabledClasses = `
    bg-blue-600 text-white hover:bg-blue-700
    dark:bg-blue-500 dark:hover:bg-blue-400
  `;

  const disabledClasses = `
    bg-gray-300 text-gray-500 cursor-not-allowed
    dark:bg-gray-700 dark:text-gray-400
  `;

  const combinedClasses = `
    ${baseClasses}
    ${disabled ? disabledClasses : enabledClasses}
    ${className}
  `.trim();

  return (
    <button
      type={type}
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      className={combinedClasses}
      aria-label={ariaLabel}
    >
      {children}
    </button>
  );
};
