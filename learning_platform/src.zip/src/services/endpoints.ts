// API endpoint constants used throughout the application
export const COURSES = '/api/courses';
export const LESSONS = '/api/lessons';
export const QUIZZES = '/api/quizzes';
export const ASSIGNMENTS = '/api/assignments';
export const GRADES = '/api/grades';
export const FORUMS = '/api/forums';
export const CERTIFICATES = '/api/certificates';
export const AUTH = '/api/auth';

// Nested endpoint helpers for specific resources
export const COURSE_ENDPOINTS = {
  LIST: COURSES,
  DETAIL: (id: string) => `${COURSES}/${id}`,
  ENROLL: (id: string) => `${COURSES}/${id}/enroll`,
  PROGRESS: (id: string) => `${COURSES}/${id}/progress`,
} as const;

export const LESSON_ENDPOINTS = {
  LIST: LESSONS,
  DETAIL: (id: string) => `${LESSONS}/${id}`,
  COMPLETE: (id: string) => `${LESSONS}/${id}/complete`,
} as const;

export const QUIZ_ENDPOINTS = {
  LIST: QUIZZES,
  DETAIL: (id: string) => `${QUIZZES}/${id}`,
  SUBMIT: (id: string) => `${QUIZZES}/${id}/submit`,
  RESULTS: (id: string) => `${QUIZZES}/${id}/results`,
} as const;

export const ASSIGNMENT_ENDPOINTS = {
  LIST: ASSIGNMENTS,
  DETAIL: (id: string) => `${ASSIGNMENTS}/${id}`,
  SUBMIT: (id: string) => `${ASSIGNMENTS}/${id}/submit`,
  FEEDBACK: (id: string) => `${ASSIGNMENTS}/${id}/feedback`,
} as const;

export const GRADE_ENDPOINTS = {
  LIST: GRADES,
  COURSE: (courseId: string) => `${GRADES}/course/${courseId}`,
  STUDENT: (studentId: string) => `${GRADES}/student/${studentId}`,
} as const;

export const FORUM_ENDPOINTS = {
  LIST: FORUMS,
  THREADS: (forumId: string) => `${FORUMS}/${forumId}/threads`,
  POSTS: (threadId: string) => `${FORUMS}/threads/${threadId}/posts`,
  CREATE_THREAD: (forumId: string) => `${FORUMS}/${forumId}/threads`,
  CREATE_POST: (threadId: string) => `${FORUMS}/threads/${threadId}/posts`,
} as const;

export const CERTIFICATE_ENDPOINTS = {
  LIST: CERTIFICATES,
  DETAIL: (id: string) => `${CERTIFICATES}/${id}`,
  GENERATE: (courseId: string) => `${CERTIFICATES}/generate/${courseId}`,
  DOWNLOAD: (id: string) => `${CERTIFICATES}/${id}/download`,
} as const;

export const AUTH_ENDPOINTS = {
  LOGIN: `${AUTH}/login`,
  LOGOUT: `${AUTH}/logout`,
  REGISTER: `${AUTH}/register`,
  PROFILE: `${AUTH}/profile`,
  REFRESH: `${AUTH}/refresh`,
} as const;
