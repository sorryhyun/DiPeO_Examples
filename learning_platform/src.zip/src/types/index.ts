// User and Authentication Types
export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: 'student' | 'instructor' | 'admin';
  avatar?: string;
  enrolledCourses: string[];
  createdAt: string;
  updatedAt: string;
}

export interface AuthToken {
  accessToken: string;
  refreshToken: string;
  expiresAt: string;
}

// Course Related Types
export interface Course {
  id: string;
  title: string;
  description: string;
  instructor: User;
  thumbnail?: string;
  duration: number; // in minutes
  lessons: Lesson[];
  enrollmentCount: number;
  rating: number;
  price: number;
  category: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Lesson {
  id: string;
  courseId: string;
  title: string;
  description: string;
  videoUrl?: string;
  duration: number; // in minutes
  order: number;
  resources: LessonResource[];
  quiz?: Quiz;
  isCompleted: boolean;
  createdAt: string;
}

export interface LessonResource {
  id: string;
  title: string;
  type: 'pdf' | 'video' | 'link' | 'document';
  url: string;
  size?: number; // in bytes
}

// Quiz Types
export interface Quiz {
  id: string;
  lessonId?: string;
  courseId?: string;
  title: string;
  description: string;
  questions: QuizQuestion[];
  timeLimit?: number; // in minutes
  passingScore: number;
  attempts: number;
  maxAttempts: number;
  isCompleted: boolean;
  score?: number;
  createdAt: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  type: 'multiple-choice' | 'true-false' | 'short-answer';
  options?: string[];
  correctAnswer: string | string[];
  explanation?: string;
  points: number;
}

// Assignment Types
export interface Assignment {
  id: string;
  courseId: string;
  title: string;
  description: string;
  dueDate: string;
  maxPoints: number;
  submissions: AssignmentSubmission[];
  requirements: string[];
  attachments: AssignmentAttachment[];
  createdAt: string;
}

export interface AssignmentSubmission {
  id: string;
  assignmentId: string;
  studentId: string;
  content: string;
  attachments: AssignmentAttachment[];
  submittedAt: string;
  grade?: Grade;
}

export interface AssignmentAttachment {
  id: string;
  name: string;
  url: string;
  type: string;
  size: number; // in bytes
}

// Grade Types
export interface Grade {
  id: string;
  studentId: string;
  courseId: string;
  assignmentId?: string;
  quizId?: string;
  score: number;
  maxScore: number;
  percentage: number;
  feedback?: string;
  gradedBy: string;
  gradedAt: string;
}

// Forum Types
export interface ForumPost {
  id: string;
  courseId: string;
  authorId: string;
  author: User;
  title: string;
  content: string;
  replies: ForumReply[];
  tags: string[];
  isPinned: boolean;
  isResolved: boolean;
  upvotes: number;
  downvotes: number;
  createdAt: string;
  updatedAt: string;
}

export interface ForumReply {
  id: string;
  postId: string;
  authorId: string;
  author: User;
  content: string;
  upvotes: number;
  downvotes: number;
  isAcceptedAnswer: boolean;
  createdAt: string;
  updatedAt: string;
}

// Certificate Types
export interface Certificate {
  id: string;
  studentId: string;
  student: User;
  courseId: string;
  course: Course;
  certificateUrl: string;
  completionDate: string;
  validUntil?: string;
  credentialId: string;
  isVerified: boolean;
}

// API Response Types
export interface ApiResponse<T> {
  data: T;
  success: boolean;
  message?: string;
  timestamp: string;
}

export interface ApiError {
  code: string;
  message: string;
  details?: Record<string, unknown>;
  timestamp: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
  success: boolean;
  message?: string;
  timestamp: string;
}

// Utility Types
export interface SelectOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface NotificationMessage {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
  duration?: number;
  timestamp: string;
}

// WebSocket Event Types
export interface WebSocketEvent {
  type: string;
  payload: unknown;
  timestamp: string;
}

export interface ProgressEvent extends WebSocketEvent {
  type: 'progress';
  payload: {
    courseId: string;
    lessonId: string;
    progress: number; // 0-100
  };
}

export interface NotificationEvent extends WebSocketEvent {
  type: 'notification';
  payload: NotificationMessage;
}
